package com.example.wkustplatform;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
//Mysql数据库的连接辅助类
public class DbOPenHelper {
    private static final String CLS = "com.mysql.cj.jdbc.Driver";
    private static final String URL = "jdbc:mysql://10.33.142.59:3306/wku_ecommerce?useUnicode=true&characterEncoding=utf8";
    private static final String USER = "local";
    private static final String PWD = "123456";


    public static Connection conn;//连接对象
    public static Statement stmt;//命令集
    public static PreparedStatement pStmt;//预编译命令集
    public static ResultSet rs; //结果集123
    //取得连接的方法
    public static void getConnection(){
        try{
            //Class.forName(CLS);
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(URL,USER,PWD);
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }
//    public static void getConnection(){
//
//        try{
//            Class.forName("com.mysql.jdbc.Driver");  //注册数据库驱动
//           // String url = "jdbc:mysql://localhost:3306/test?user=root＆password=root";  //定义连接数据库的url
//            conn = DriverManager.getConnection(URL);  //获取数据库连接
//            System.out.println("数据库连接成功！");
//
//        }catch(Exception e){
//            e.printStackTrace();
//        }
//
//    }

    //关闭数据库操作对象
    public static void clossAll(){
        try{
            if(rs!=null){
                rs.close();
                rs =null;
            }
            if(stmt!=null){
                stmt.close();
                stmt =null;
            }
            if(pStmt!=null){
                pStmt.close();
                pStmt =null;
            }
            if(conn!=null){
                conn.close();
                conn=null;
            }
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }
}


























