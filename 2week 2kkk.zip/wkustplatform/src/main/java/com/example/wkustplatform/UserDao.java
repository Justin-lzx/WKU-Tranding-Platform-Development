package com.example.wkustplatform;

import java.util.ArrayList;
import java.util.List;

//用户数据库操作类
//实现用户的crud操作
public class UserDao extends DbOPenHelper {
    //查询所有的用户信息 R
    public List<Userinfo> getAllUserList(){
        List<Userinfo> list = new ArrayList<>();
        try {
            getConnection();//取得连接信息
            String sql ="select * from students_consumers";
            pStmt = conn.prepareStatement(sql);
            rs = pStmt.executeQuery();
            if(rs.next()){
                Userinfo item = new Userinfo();
                item.setUid(rs.getString("id_students_consumers"));
                item.setUname(rs.getString("student_name"));
                item.setUpassword(rs.getString("password"));

                list.add(item);
            }
        }catch (Exception ex){
            ex.printStackTrace();
        }finally {
            clossAll();
        }
        return  list;

    }
    //按用户名和密码进行查询 R
    //读取成功则返回非null的item
    public Userinfo getUserByUnameAndUpassward(String uname,String upassword){
        Userinfo item = null;
        try {
            getConnection();//取得连接信息
            String sql ="select * from students_consumers where `student_ID` =? and `password` =?";
            pStmt = conn.prepareStatement(sql);
            pStmt.setString(1,uname);
            pStmt.setString(2,upassword);
            rs = pStmt.executeQuery();
            if(rs.next()){
                item = new Userinfo();
                //item.setUid(rs.getInt("id_students_consumers"));
                item.setUname(uname);
                item.setUpassword(upassword);
            }
        }catch (Exception ex){
            ex.printStackTrace();
        }finally {
            clossAll();
        }
        return  item;
    }
    //删除用户信息 D
    //id 删除用户的id
    //return irow 影响的行数
    //返回0则不成功
    public int delUser(int id){
        int iRow =0;
        try {
            getConnection();//取得连接信息
            String sql ="delete from students_consumers where id_students_consumers = ?";
            pStmt = conn.prepareStatement(sql);
            pStmt.setInt(1,id);
            iRow = pStmt.executeUpdate();
        }catch (Exception ex){
            ex.printStackTrace();
        }finally {
            clossAll();
        }
        return iRow;
    }
    //添加用户信息C
    //item 添加的用户
    //return irow 影响的行数
    public int addUser(Userinfo item){
        int iRow =0;//不成功
        try {
            getConnection();//取得连接信息
            String sql ="insert into students_consumers(`student_name`,`password`,`student_ID`) values(?,?,?)";
            pStmt = conn.prepareStatement(sql);
            pStmt.setString(1,item.getUname());
            pStmt.setString(2,item.getUpassword());
            pStmt.setString(3,item.getUid());
            iRow = pStmt.executeUpdate();
        }catch (Exception ex){
            ex.printStackTrace();
        }finally {
            clossAll();
        }
        return iRow;
    }
    //修改用户信息 U
    //item 添加的用户
    //return irow 影响的行数
    public int editUser(Userinfo item){
        int iRow =0;//不成功
        try {
            getConnection();//取得连接信息
            String sql ="update students_consumers set `student_name` =?, `password` =? where `id_students_consumers` = ?";
            pStmt = conn.prepareStatement(sql);
            pStmt.setString(1,item.getUname());
            pStmt.setString(2,item.getUpassword());
            pStmt.setString(3,item.getUid());
            iRow = pStmt.executeUpdate();
        }catch (Exception ex){
            ex.printStackTrace();
        }finally {
            clossAll();
        }
        return iRow;
    }
}
