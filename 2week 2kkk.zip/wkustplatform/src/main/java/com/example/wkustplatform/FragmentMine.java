package com.example.wkustplatform;

import android.app.Activity;
import android.os.Bundle;

public class FragmentMine extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_mine);
    }
}
