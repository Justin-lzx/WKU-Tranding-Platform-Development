package com.example.wkustplatform;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Item_Commodity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_commodity);

    }
    public void onClickBack(View v) {
                Intent intent = new Intent(Item_Commodity.this, Goods_details.class);
                startActivity(intent);
            }

   public void onClickBuy(View v) {
                Intent intent = new Intent(Item_Commodity.this, Add_goods.class);
                startActivity(intent);
            }
}

