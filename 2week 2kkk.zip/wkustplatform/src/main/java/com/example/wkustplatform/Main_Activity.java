package com.example.wkustplatform;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Main_Activity extends AppCompatActivity {
    private Handler mainHandler;
    int msg =0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText accountID = (EditText) findViewById(R.id.accountID);
        String ID = accountID.getText().toString();
        EditText passwordText = (EditText) findViewById(R.id.password);
        String password = passwordText.getText().toString();
        }
    public void onClickLog(View v) {
        login(v);
        if(msg==1){
            Intent intent = new Intent(Main_Activity.this, MainPage.class);
            startActivity(intent);
        }
    }
    public void login(View v){

        EditText EditTextname = (EditText)findViewById(R.id.accountID);
        EditText EditTextpassword = (EditText)findViewById(R.id.password);
        String userID = EditTextname.getText().toString();
        String usePWD = EditTextpassword.getText().toString();
        new Thread(){
            @Override
            public void run() {

                UserDao userDao = new UserDao();
                Userinfo u ;
                u = userDao.getUserByUnameAndUpassward(userID,usePWD);
                msg = 0;
                if(u!=null){
                    msg = 1;
                }
                hand1.sendEmptyMessage(msg);
            }
        }.start();


    }
    final Handler hand1 = new Handler()
    {
        @Override
        public void handleMessage(Message msg) {

            if(msg.what == 1)
            {
                Toast.makeText(getApplicationContext(),"登录成功",Toast.LENGTH_LONG).show();

            }
            else
            {
                Toast.makeText(getApplicationContext(),"登录失败",Toast.LENGTH_LONG).show();
            }
        }
    };

    public void onClickRegister(View v) {
        Intent intent = new Intent(Main_Activity.this, Register.class);
        startActivity(intent);
    }

    public void onClickForget(View v) {
        Intent intent = new Intent(Main_Activity.this, Forget.class);
        startActivity(intent);
    }

    }
