package com.example.wkustplatform;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Forget extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.forget);

        EditText aI=(EditText) findViewById(R.id.al);
        String f_accountId=aI.getText().toString();

        EditText stuid=(EditText) findViewById(R.id.stuid);
        String f_stuid=stuid.getText().toString();

    }
    public void onClick(View v) {
        Intent intent = new Intent(Forget.this, Main_Activity.class);
        startActivity(intent);
    }
    }


