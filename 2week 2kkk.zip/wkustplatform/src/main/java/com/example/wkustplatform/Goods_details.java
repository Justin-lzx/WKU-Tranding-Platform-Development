package com.example.wkustplatform;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Goods_details extends Activity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goods_details);

    }
    public void onClickDetail(View v) {
                Intent intent = new Intent(Goods_details.this, Item_Commodity.class);
                startActivity(intent);
            }

    public void onClickBuy(View v) {
                Intent intent = new Intent(Goods_details.this, Add_goods.class);
                startActivity(intent);
            }
}




