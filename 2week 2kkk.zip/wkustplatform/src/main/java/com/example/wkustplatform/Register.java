package com.example.wkustplatform;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Register extends AppCompatActivity {
    private UserDao dao;//用户数据操作类(使用时需要在initview上实例化)
    private Handler mainHandler;//主线程
    String r_name=null;
    String r_phoneNumber=null;
    String r_confPassWord=null;
    String r_gender=null;
    String r_passWord=null;
    String r_location=null;
    String s_stuid=null;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.acrivity_register);


        EditText aI=(EditText) findViewById(R.id.al);
        if (r_name!=null && r_name.trim().length()>0){
            r_name = aI.getText().toString();
        }

        EditText phn=(EditText) findViewById(R.id.phn);
        if (r_phoneNumber!=null && r_phoneNumber.trim().length()>0) {
            r_phoneNumber=phn.getText().toString();}

        EditText paw=(EditText) findViewById(R.id.paw);
        if (r_passWord!=null && r_passWord.trim().length()>0) {
            r_passWord=paw.getText().toString();
        }

        EditText cpaw=(EditText) findViewById(R.id.cpaw);
        if (r_confPassWord!=null && r_confPassWord.trim().length()>0){
            r_confPassWord=cpaw.getText().toString();
        }

        Spinner genderselect=(Spinner) findViewById(R.id.genderselect);
        if (r_gender!=null && r_gender.trim().length()>0) {
            r_gender=genderselect.getSelectedItem().toString();
        }

        Spinner locationselect=(Spinner) findViewById(R.id.locationselect);
        if (r_location!=null && r_location.trim().length()>0){
            r_location=locationselect.getSelectedItem().toString();
        }

        EditText stuid=(EditText) findViewById(R.id.stuid);
        if(s_stuid!=null && s_stuid.trim().length()>0) {
            s_stuid=stuid.getText().toString();
        }

    }
    public void onClick(View v) {
        register(v);
        Intent intent = new Intent(Register.this, Main_Activity.class);
        startActivity(intent);
    }

    public void register(View view){
        EditText aI=(EditText) findViewById(R.id.al);
            r_name = aI.getText().toString();

        EditText paw=(EditText) findViewById(R.id.paw);
            r_passWord=paw.getText().toString();

        EditText stuid=(EditText) findViewById(R.id.stuid);
            s_stuid=stuid.getText().toString();

        Userinfo user = new Userinfo();
        user.setUname(r_name);
        user.setUpassword(r_passWord);
        user.setUid(s_stuid);
        new Thread(){
            @Override
            public void run() {

                int msg = 0;

                UserDao userDao = new UserDao();

                Userinfo uu = userDao.getUserByUnameAndUpassward(user.getUname(),user.getUpassword());

                if(uu != null){
                    msg = 1;
                }
                int flag = userDao.addUser(user);
                if(flag==1){
                    msg = 2;
                }
                hand.sendEmptyMessage(msg);

            }
        }.start();
    }final Handler hand = new Handler()
    {
        @Override
        public void handleMessage(Message msg) {
            if(msg.what == 0)
            {
                Toast.makeText(getApplicationContext(),"注册失败",Toast.LENGTH_LONG).show();

            }
            if(msg.what == 1)
            {
                Toast.makeText(getApplicationContext(),"该账号已经存在，请换一个账号",Toast.LENGTH_LONG).show();
            }
            if(msg.what == 2)
            {
                //startActivity(new Intent(getApplication(),MainActivity.class));

                Intent intent = new Intent();
                //将想要传递的数据用putExtra封装在intent中
                intent.putExtra("a","註冊");
                setResult(RESULT_CANCELED,intent);
                finish();
            }

        }
    };



}
