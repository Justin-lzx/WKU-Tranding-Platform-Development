package com.example.wkustplatform;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Spinner;

public class Add_goods extends Activity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_add_goods);

        EditText amount=(EditText) findViewById(R.id.input_count);
        String selectAmount=amount.getText().toString();
    }

    public void onClickConfirm(View view) {
        Intent intent = new Intent(Add_goods.this, Add_goods.class);
        startActivity(intent);
    }


    public void onClickCancel(View v) {
                Intent intent = new Intent(Add_goods.this, Goods_details.class);
                startActivity(intent);

        };

}
