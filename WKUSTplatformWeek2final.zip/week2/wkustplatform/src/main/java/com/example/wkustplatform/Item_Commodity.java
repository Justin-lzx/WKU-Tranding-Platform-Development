package com.example.wkustplatform;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Item_Commodity extends Activity {

    Button bt_back;
    Button  bt_buy;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_commodity);

    }

    public void onButtonClick(View view) {
        bt_back = findViewById(R.id.item_back);
        bt_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Item_Commodity.this, Goods_details.class);
                startActivity(intent);
            }
        });
        bt_buy = findViewById(R.id.item_add);
        bt_buy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Item_Commodity.this, Add_goods.class);
                startActivity(intent);
            }
        });

    }
}

