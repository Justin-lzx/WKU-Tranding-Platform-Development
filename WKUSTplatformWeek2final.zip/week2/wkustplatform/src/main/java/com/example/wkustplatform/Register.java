package com.example.wkustplatform;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import java.io.File;

public class Register extends Activity {
    Button bt_conRegister;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.forget);

        EditText aI=(EditText) findViewById(R.id.al);
        String r_accountId=aI.getText().toString();

        EditText phn=(EditText) findViewById(R.id.phn);
        String r_phoneNumber=phn.getText().toString();

        EditText paw=(EditText) findViewById(R.id.paw);
        String r_passWord=paw.getText().toString();

        EditText cpaw=(EditText) findViewById(R.id.cpaw);
        String r_confPassWord=cpaw.getText().toString();


        Spinner genderselect=(Spinner) findViewById(R.id.genderselect);
        String r_gender=genderselect.getSelectedItem().toString();

        Spinner locationselect=(Spinner) findViewById(R.id.locationselect);
        String r_location=locationselect.getSelectedItem().toString();

        EditText stuid=(EditText) findViewById(R.id.stuid);
        String r_stuid=stuid.getText().toString();

    }
    public void onButtonClick(View view) {
        bt_conRegister = findViewById(R.id.confirm_button);
        bt_conRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Register.this, MainActivity.class);
                startActivity(intent);
            }
        });

    }
}
