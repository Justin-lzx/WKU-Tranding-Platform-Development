package com.example.wkustplatform;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Goods_details extends Activity {

    Button bt_details;
    Button bt_addThing;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goods_details);

    }

    public void onButtonClick(View view) {
        bt_details = findViewById(R.id.view_details);
        bt_details.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Goods_details.this, Item_Commodity.class);
                startActivity(intent);
            }
        });
        bt_addThing = findViewById(R.id.add_thing);
        bt_addThing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Goods_details.this, Add_goods.class);
                startActivity(intent);
            }
        });

    }
}

