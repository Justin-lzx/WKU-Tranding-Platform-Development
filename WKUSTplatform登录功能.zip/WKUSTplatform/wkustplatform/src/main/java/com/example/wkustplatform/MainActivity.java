package com.example.wkustplatform;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button bt_register;
    Button bt_forget;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bt_register=findViewById(R.id.confirm_button);
        bt_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,Register.class);
                startActivity(intent);
            }
        });
        bt_forget=findViewById(R.id.forget);
        bt_forget.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,Forget.class);
                startActivity(intent);
            }
        });

        EditText accountID=(EditText) findViewById(R.id.accountID);
        String ID=accountID.getText().toString();

        EditText passwordText=(EditText) findViewById(R.id.password);
        String password=passwordText.getText().toString();


    }
}