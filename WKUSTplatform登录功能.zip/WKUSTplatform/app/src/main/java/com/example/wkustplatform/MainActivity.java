package com.example.wkustplatform;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private UserDao dao;//用户数据操作类(使用时需要在initview上实例化)
    private EditText et_uname,et_upass ;//用户名，密码框
    private Handler mainHandler;//主线程
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }



    private Handler handler = new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            //super.handleMessage(msg);
        if (msg.what==0){
            int count = (Integer)msg.obj;
            //获得数据
            //怎么使用就自己搞
        }
        }
    };
    //执行查询用户数量的方法
    private  void doQueryCount(){
        new Thread(new Runnable() {
            @Override
            public void run() {

                int count = MySqlHelp.getUserSize();
                Message msg = Message.obtain();
                msg.what =0;
                msg.obj = count;
                //向主线程发送数据
                handler.sendMessage(msg);
            }
        }).start();
    }
    //登录功能
    private void  dologin(){
       final String uname = et_uname.getText().toString().trim();//获取文本框的数据
       final String upass = et_upass.getText().toString().trim();

        new Thread(new Runnable() {
            @Override
            public void run() {
                final Userinfo item = dao.getUserByUnameAndUpassward(uname,upass);

                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if(item==null){
                            //登录不成功
                        }else {
                            //登录成功
                        }
                    }
                });

            }
        }).start();
    }






}