package com.example.wkustplatform;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

//直接链接数据库的辅助工具类
public class MySqlHelp {
    //获取用户数量
    public static int getUserSize(){
        final String CLS = "com.mysql.jdbc.Driver";
        final String URL = "jdbc:mysql://192.168.101.20";
        final String USER = "test";
        final String PWD = "123456";
    int count =0;
    try{
        Class.forName(CLS);
        Connection conn = DriverManager.getConnection(URL,USER,PWD);
        String sql="SELECT COUNT(1) AS sl FROM `user`";
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(sql);
        while(rs.next()){
            count = rs.getInt( "s1");
        }
    }catch(Exception ex){
        ex.printStackTrace();
    }
    return count;
    }

}
