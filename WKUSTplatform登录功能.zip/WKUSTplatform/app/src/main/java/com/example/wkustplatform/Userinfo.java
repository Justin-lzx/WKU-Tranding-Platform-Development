package com.example.wkustplatform;

import  java.io.Serializable;
//用户信息实体类
public class Userinfo implements Serializable {
    private int uid;
    private String uname;
    private String upassword;

    public Userinfo(){

    }

    public Userinfo(int uid, String uname, String upassword) {
        this.uid = uid;
        this.uname = uname;
        this.upassword = upassword;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }

    public String getUpassword() {
        return upassword;
    }

    public void setUpassword(String upassword) {
        this.upassword = upassword;
    }
}
